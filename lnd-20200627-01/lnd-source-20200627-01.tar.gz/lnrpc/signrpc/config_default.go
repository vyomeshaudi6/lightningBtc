// +build !signrpc

package signrpc

// Config is empty for non-signrpc builds.
type Config struct{}
